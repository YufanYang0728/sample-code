<?php

namespace App\Controller;

class RiskAndInvestmentController extends AppController
{
public function index(){

}
}
