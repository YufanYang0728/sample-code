<div class="row justify-content-center">
<div class=" text-center">
    <div class="card shadow mb-lg-1">
        <div class="card-header py-sm-5">
            <h6 class="m-0 font-weight-bold text-primary" style="font-size:50px">Access denied</h6>
        </div>
        <div class="card-body">
            <h1 class="h6">You don't have the access to this page.</h1>
            <a class="btn btn-warning btn-icon-split btn-" style="align-content: center" onclick="goBack()">
                    <span class="icon text-white-100">
                       <i class="fas fa-arrow-left"></i>
                    </span>
                <span class="text">Go back</span>
            </a>
        </div>

    </div>
</div>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
