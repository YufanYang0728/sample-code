<meta name="viewport" content="width=device-width, initial-scale=1.0">
<html lang="en">
<head>
    <!-- Custom styles for this template -->
    <link href="../webroot/css/form-validation.css" rel="stylesheet">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>
        .hide {
            display: none;
        }
    </style>
</head>


<body class="bg-light">
<div class="container-fluid">
    <main class="py-5 text-center">
        <div class="py-5 text-center">
            <h2 class="section-heading text-uppercase">explore super options</h2>
            <p class="section-subheading text-muted">Let's help you find the suitable super option!</p>
        </div>
    </main>
</div>
</body>

