// <script src="../webroot/js/clearview_occupations.js" type="text/javascript">
//     window.onload = populateSelect();
//     function populateSelect() {
//     alert(occupation2[0].Description);
//     var ele = document.getElementById('occupation');
//     for (var i = 0; i < occupation2.length; i++) {
//
//     // Bind data to <select> element.
//     ele.innerHTML = ele.innerHTML +
//     '<option value="' + occupation2[i].Key + '">' + occupation2[i].Description + '</option>';
// }
// }
//
// </script>
//
// <script src="../webroot/js/neos_occupations.js" type="text/javascript">
//     window.onload = populateSelection();
//     function populateSelection() {
//     var ele = document.getElementById("neooccupation");
//     for (var i = 0; i < occupation1.length; i++) {
//
//     // Bind data to <select> element.
//     ele.innerHTML = ele.innerHTML +
//     '<option value="'+ occupation1[i].Code + '">' + occupation1[i].Value + '</option>';
// }
// }
// </script>
//
// <?php
// $this->Html->script("../../webroot/js/form-validation.js");
//
// echo '<script type="text/javascript">
// window.onload = populateSelect();
// function populateSelect() {
//     var ele = document.getElementById("occupation");
//     for (var i = 0; i < occupation2.length; i++) {
//
//         // Bind data to <select> element.
//         ele.innerHTML = ele.innerHTML +
//             "<option value=\""+ occupation2[i].Key + "\">" + occupation2[i].Description + "</option>";
//     }
//     var ele1 = document.getElementById("neooccupation");
//     for (var i = 0; i < occupation1.length; i++) {
//
//         // Bind data to <select> element.
//         ele1.innerHTML = ele1.innerHTML +
//             "<option value=\""+ occupation1[i].Code + "\">" + occupation1[i].Value + "</option>";
//     }
// }
// </script>'
//
//
// ;
// ?>
